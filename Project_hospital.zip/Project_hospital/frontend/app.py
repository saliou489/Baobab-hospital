"""Interface Streamlit de MédiRDV : navigation sobre par profil (Agent, Médecin, Direction).

Lancement (depuis la racine du projet) :

    streamlit run frontend/app.py

Variables d'environnement :
- MEDIRDV_API_URL : adresse de l'API (défaut : http://127.0.0.1:8000) ;
- NOM_CLINIQUE : nom affiché dans le menu latéral (défaut : BAOBAB).

Résilience : tous les appels passent par ``api_client`` (try/except RequestException). Si le
serveur est indisponible, l'interface affiche une bannière, conserve les dernières listes de
référence connues et désactive les enregistrements tant que le service ne répond pas.
Aucune règle métier n'est tranchée ici : l'API reste l'unique juge (conflits, motifs, formats).
"""
import os
import sys
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import pandas as pd  # noqa: E402
import streamlit as st  # noqa: E402

import api_client  # noqa: E402
from api_client import ErreurApi  # noqa: E402

st.set_page_config(page_title="MédiRDV", layout="wide")

NOM_CLINIQUE = os.getenv("NOM_CLINIQUE", "BAOBAB")
DUREE_VALIDITE_LISTES_S = 60

PROFILS = ["Agent d'accueil", "Médecin", "Direction"]
CANAUX = ["Téléphone", "Guichet", "Recommandation médecin"]
MOTIFS_ANNULATION = ["Patient", "Médecin", "Clinique", "Autre"]
STATUTS_OCCUPANT_UN_CRENEAU = ["Planifié", "Confirmé", "Honoré"]
STATUTS_PLANNING = ["Planifié", "Confirmé", "Honoré", "Absent"]


# --------------------------------------------------------------------------------------
# Utilitaires d'affichage
# --------------------------------------------------------------------------------------


def aujourdhui() -> date:
    """Date du jour à Dakar (UTC+0 toute l'année)."""
    return datetime.now(timezone.utc).date()


def format_date(valeur: str) -> str:
    return date.fromisoformat(valeur).strftime("%d/%m/%Y")


def format_heure(valeur: str) -> str:
    return valeur[:5]


def format_pourcentage(valeur: float | None) -> str:
    """Un taux absent signifie « non calculable » (aucun rendez-vous honoré ou absent), pas 0 %."""
    return "Non calculable" if valeur is None else f"{valeur:.1f} %".replace(".", ",")


def libelle_patient(patient: dict) -> str:
    telephone = patient.get("telephone") or "téléphone non renseigné"
    return f"{patient['nom']} {patient['prenom']} - {telephone} - {patient['id']}"


def libelle_medecin(medecin: dict) -> str:
    return f"{medecin['nom']} ({medecin['specialite']})"


def heure_de_fin(rdv: dict) -> str:
    debut = datetime.combine(date.fromisoformat(rdv["date_rdv"]), time.fromisoformat(rdv["heure_rdv"]))
    return (debut + timedelta(minutes=rdv["duree_min"])).strftime("%H:%M")


def afficher_erreur(erreur: ErreurApi) -> None:
    """Bannière sobre : avertissement pour une saisie à corriger, erreur pour un refus ou une panne."""
    if erreur.indisponible:
        st.error(f"Service momentanément indisponible. {erreur.message} Réessayez dans quelques instants.")
    elif erreur.statut_http in (400, 422):
        st.warning(erreur.message)
    else:
        st.error(erreur.message)
    st.caption(f"Code : {erreur.code_erreur}")


def appel(fonction, *args, **kwargs):
    """Exécute un appel API ; en cas d'échec, affiche la bannière adaptée et retourne None."""
    try:
        return fonction(*args, **kwargs)
    except ErreurApi as erreur:
        afficher_erreur(erreur)
        return None


def tableau(lignes: list[dict]) -> None:
    if lignes:
        st.dataframe(pd.DataFrame(lignes), hide_index=True)
    else:
        st.info("Aucun élément à afficher.")


# --------------------------------------------------------------------------------------
# Listes de référence avec repli
# --------------------------------------------------------------------------------------


def charger_referentiels(forcer: bool = False) -> tuple[dict | None, bool]:
    """Retourne (listes, hors_ligne).

    Les listes (agents, médecins) sont rechargées toutes les 60 secondes. Si l'API est
    indisponible, les dernières listes connues sont conservées (hors_ligne = True) ;
    s'il n'en existe aucune, la valeur retournée est None.
    """
    memoire = st.session_state.get("referentiels")
    if memoire and not forcer:
        age = (datetime.now() - memoire["horodatage"]).total_seconds()
        if age < DUREE_VALIDITE_LISTES_S:
            return memoire, False
    try:
        listes = {
            "agents": api_client.lister_agents(),
            "medecins": api_client.lister_medecins(),
            "horodatage": datetime.now(),
        }
    except ErreurApi as erreur:
        if memoire:
            st.warning(
                f"Le service est indisponible : les listes affichées datent de {memoire['horodatage']:%H:%M}. "
                "Les enregistrements sont désactivés tant que le service ne répond pas."
            )
            st.caption(f"Détail : {erreur.message}")
            return memoire, True
        afficher_erreur(erreur)
        return None, True
    st.session_state["referentiels"] = listes
    return listes, False


# --------------------------------------------------------------------------------------
# Composants communs aux pages
# --------------------------------------------------------------------------------------


def selection_patient(cle: str) -> str | None:
    """Recherche un patient puis retourne l'identifiant choisi (ou None)."""
    texte = st.text_input(
        "Rechercher un patient (nom, prénom, téléphone ou identifiant)", key=f"recherche_{cle}", max_chars=60
    ).strip()
    if len(texte) < 2:
        st.caption("Saisissez au moins 2 caractères.")
        return None
    resultat = appel(api_client.rechercher_patients, texte, 20)
    if resultat is None:
        return None
    if not resultat["elements"]:
        st.info("Aucun patient ne correspond à cette recherche.")
        return None
    if resultat["total"] > len(resultat["elements"]):
        st.caption(f"{resultat['total']} résultats : affinez la recherche pour voir les autres.")
    libelles = {p["id"]: libelle_patient(p) for p in resultat["elements"]}
    return st.selectbox("Patient", options=list(libelles), format_func=libelles.get, key=f"choix_{cle}")


def afficher_alerte_recidiviste(alerte: dict) -> None:
    """RG-08 : avertissement contextuel pour l'agent (non bloquant)."""
    if alerte["actif"]:
        st.warning(alerte["message"])


def afficher_creneaux_occupes(medecin_id: str, jour: date) -> None:
    """Aide à la saisie : créneaux du médecin déjà pris ce jour-là."""
    donnees = appel(
        api_client.lister_rdv,
        medecin_id=medecin_id,
        statuts=STATUTS_OCCUPANT_UN_CRENEAU,
        date_debut=jour,
        date_fin=jour,
    )
    if donnees is None:
        return
    st.caption(f"Créneaux déjà occupés le {jour:%d/%m/%Y} :")
    if not donnees["elements"]:
        st.caption("Aucun créneau occupé ce jour-là.")
        return
    tableau(
        [
            {"Début": format_heure(r["heure_rdv"]), "Fin": heure_de_fin(r), "Statut": r["statut"]}
            for r in donnees["elements"]
        ]
    )


def afficher_message_en_attente() -> None:
    """Affiche (une seule fois) le message de succès préparé avant un rechargement de page."""
    message = st.session_state.pop("_succes", None)
    if message:
        st.success(message)


# --------------------------------------------------------------------------------------
# Profil Agent d'accueil
# --------------------------------------------------------------------------------------


def formulaire_creation_patient() -> None:
    """Création d'une fiche patient (la validation stricte est faite par l'API)."""
    with st.form("formulaire_patient"):
        colonne_nom, colonne_prenom = st.columns(2)
        nom = colonne_nom.text_input("Nom", max_chars=80)
        prenom = colonne_prenom.text_input("Prénom", max_chars=80)
        sexe = st.radio("Sexe", ["Féminin", "Masculin"], horizontal=True)
        naissance = st.date_input(
            "Date de naissance",
            value=None,
            min_value=date(1900, 1, 1),
            max_value=aujourdhui(),
            format="DD/MM/YYYY",
        )
        telephone = st.text_input(
            "Téléphone",
            max_chars=20,
            help="9 chiffres sans espace, commençant par 77, 78, 76, 70, 75 ou 33.",
        )
        quartier = st.text_input("Quartier (facultatif)", max_chars=60)
        envoye = st.form_submit_button("Créer la fiche patient")
    if not envoye:
        return
    if naissance is None:
        st.warning("Renseignez la date de naissance.")
        return
    patient = appel(
        api_client.creer_patient,
        nom,
        prenom,
        "F" if sexe == "Féminin" else "M",
        naissance,
        telephone,
        quartier or None,
    )
    if patient:
        st.session_state["_prefill_recherche_nouveau"] = patient["id"]
        st.session_state["_succes"] = f"Fiche patient {patient['id']} créée : {patient['nom']} {patient['prenom']}."
        st.rerun()


def page_nouveau_rdv(listes: dict, agent_id: str, hors_ligne: bool) -> None:
    st.header("Nouveau rendez-vous")
    # Le champ de recherche est pré-rempli avec la fiche qui vient d'être créée (avant son affichage).
    if "_prefill_recherche_nouveau" in st.session_state:
        st.session_state["recherche_nouveau"] = st.session_state.pop("_prefill_recherche_nouveau")
    afficher_message_en_attente()

    st.subheader("1. Patient")
    patient_id = selection_patient("nouveau")
    with st.expander("Créer une fiche patient"):
        formulaire_creation_patient()
    patient = None
    if patient_id:
        patient = appel(api_client.obtenir_patient, patient_id)
        if patient:
            afficher_alerte_recidiviste(patient["alerte_recidiviste"])

    st.subheader("2. Rendez-vous")
    medecins = listes["medecins"]
    colonne_specialite, colonne_medecin = st.columns(2)
    specialite = colonne_specialite.selectbox(
        "Spécialité", sorted({m["specialite"] for m in medecins}), key="specialite_nouveau"
    )
    medecins_de_la_specialite = {m["id"]: m for m in medecins if m["specialite"] == specialite}
    medecin_id = colonne_medecin.selectbox(
        "Médecin",
        list(medecins_de_la_specialite),
        format_func=lambda i: medecins_de_la_specialite[i]["nom"],
        key="medecin_nouveau",
    )
    colonne_date, colonne_heure, colonne_canal = st.columns(3)
    jour = colonne_date.date_input(
        "Date", value=aujourdhui(), min_value=aujourdhui(), format="DD/MM/YYYY", key="date_nouveau"
    )
    heure = colonne_heure.time_input("Heure", value=time(9, 0), step=300, key="heure_nouveau")
    canal = colonne_canal.selectbox("Canal de prise de rendez-vous", ["Non précisé"] + CANAUX, key="canal_nouveau")
    if medecin_id:
        afficher_creneaux_occupes(medecin_id, jour)

    if patient is None:
        st.caption("Sélectionnez un patient pour activer l'enregistrement.")
    if st.button(
        "Enregistrer le rendez-vous", disabled=(patient is None or hors_ligne or not medecin_id), key="enregistrer"
    ):
        reponse = appel(
            api_client.creer_rdv,
            patient_id,
            medecin_id,
            agent_id,
            jour,
            heure,
            None if canal == "Non précisé" else canal,
        )
        if reponse:
            rdv = reponse["rdv"]
            st.session_state["_resultat_rdv"] = {
                "message": (
                    f"Rendez-vous {rdv['id']} enregistré : {rdv['medecin_nom']}, le {format_date(rdv['date_rdv'])} "
                    f"à {format_heure(rdv['heure_rdv'])} ({rdv['duree_min']} minutes)."
                ),
                "avertissements": [a["message"] for a in reponse["avertissements"]],
            }
            st.rerun()  # recharge la page pour que la liste des créneaux occupés soit à jour
    resultat = st.session_state.pop("_resultat_rdv", None)
    if resultat:
        st.success(resultat["message"])
        for message in resultat["avertissements"]:
            st.warning(message)  # RG-08 : alerte non bloquante


def page_rendez_vous_patient(hors_ligne: bool) -> None:
    st.header("Rendez-vous d'un patient")
    afficher_message_en_attente()
    patient_id = selection_patient("gestion")
    if not patient_id:
        return
    historique = appel(api_client.historique_patient, patient_id)
    if historique is None:
        return

    afficher_alerte_recidiviste(historique["alerte_recidiviste"])
    colonnes = st.columns(4)
    colonnes[0].metric("Rendez-vous", historique["total_rdv"])
    colonnes[1].metric("Honorés", historique["honores"])
    colonnes[2].metric("Absences", historique["absents"])
    colonnes[3].metric("Taux d'absence", format_pourcentage(historique["taux_absence_pct"]))
    st.caption(
        "Taux d'absence = absences / (honorés + absences). Les rendez-vous planifiés, confirmés et annulés "
        "sont exclus du calcul."
    )
    rendez_vous = historique["rendez_vous"]
    tableau(
        [
            {
                "Identifiant": r["id"],
                "Date": format_date(r["date_rdv"]),
                "Heure": format_heure(r["heure_rdv"]),
                "Médecin": r["medecin_nom"],
                "Spécialité": r["specialite"],
                "Statut": r["statut"],
                "Motif d'annulation": r["motif_annulation"] or "",
            }
            for r in rendez_vous
        ]
    )

    modifiables = {r["id"]: r for r in rendez_vous if r["statut"] in ("Planifié", "Confirmé")}
    st.subheader("Modifier un rendez-vous")
    if not modifiables:
        st.caption("Aucun rendez-vous planifié ou confirmé à modifier.")
        return
    rdv_id = st.selectbox(
        "Rendez-vous",
        list(modifiables),
        format_func=lambda i: (
            f"{i} - {format_date(modifiables[i]['date_rdv'])} {format_heure(modifiables[i]['heure_rdv'])} - "
            f"{modifiables[i]['medecin_nom']} - {modifiables[i]['statut']}"
        ),
        key="rdv_a_modifier",
    )
    action = st.radio("Action", ["Confirmer", "Reporter", "Annuler"], horizontal=True, key="action_rdv")
    nouvelle_date = nouvelle_heure = motif = None
    if action == "Reporter":
        colonne_date, colonne_heure = st.columns(2)
        nouvelle_date = colonne_date.date_input(
            "Nouvelle date", value=aujourdhui(), min_value=aujourdhui(), format="DD/MM/YYYY", key="nouvelle_date"
        )
        nouvelle_heure = colonne_heure.time_input("Nouvelle heure", value=time(9, 0), step=300, key="nouvelle_heure")
    elif action == "Annuler":
        motif = st.selectbox("Motif d'annulation", MOTIFS_ANNULATION, key="motif_annulation")

    if st.button("Appliquer", disabled=hors_ligne, key="appliquer_action"):
        if action == "Confirmer":
            resultat = appel(api_client.modifier_rdv, rdv_id, statut="Confirmé")
            message = f"Rendez-vous {rdv_id} confirmé."
        elif action == "Reporter":
            resultat = appel(api_client.modifier_rdv, rdv_id, date_rdv=nouvelle_date, heure_rdv=nouvelle_heure)
            message = f"Rendez-vous {rdv_id} reporté au {nouvelle_date:%d/%m/%Y} à {nouvelle_heure:%H:%M}."
        else:
            resultat = appel(api_client.modifier_rdv, rdv_id, statut="Annulé", motif_annulation=motif)
            message = f"Rendez-vous {rdv_id} annulé (motif : {motif})."
        if resultat:
            st.session_state["_succes"] = message
            st.rerun()


# --------------------------------------------------------------------------------------
# Profil Médecin
# --------------------------------------------------------------------------------------


def page_planning_medecin(medecin: dict, hors_ligne: bool) -> None:
    st.header("Planning du médecin")
    afficher_message_en_attente()
    st.caption(libelle_medecin(medecin))
    jour_courant = aujourdhui()
    periode = st.date_input(
        "Période",
        value=(jour_courant, jour_courant + timedelta(days=6)),
        format="DD/MM/YYYY",
        key="periode_medecin",
    )
    if not isinstance(periode, (tuple, list)) or len(periode) != 2:
        st.info("Sélectionnez une date de début et une date de fin.")
        return
    donnees = appel(
        api_client.lister_rdv,
        medecin_id=medecin["id"],
        statuts=STATUTS_PLANNING,
        date_debut=periode[0],
        date_fin=periode[1],
    )
    if donnees is None:
        return
    rendez_vous = donnees["elements"]
    if donnees["total"] > len(rendez_vous):
        st.caption(f"{donnees['total']} rendez-vous sur la période : seuls les {len(rendez_vous)} premiers sont affichés.")
    tableau(
        [
            {
                "Date": format_date(r["date_rdv"]),
                "Heure": format_heure(r["heure_rdv"]),
                "Durée (min)": r["duree_min"],
                "Patient": r["patient_nom"],
                "Statut": r["statut"],
                "Canal": r["canal"] or "",
            }
            for r in rendez_vous
        ]
    )

    st.subheader("Clôturer un rendez-vous")
    a_cloturer = {
        r["id"]: r
        for r in rendez_vous
        if r["statut"] in ("Planifié", "Confirmé") and date.fromisoformat(r["date_rdv"]) <= jour_courant
    }
    if not a_cloturer:
        st.caption("Aucun rendez-vous du jour ou antérieur en attente d'être marqué honoré ou absent.")
        return
    rdv_id = st.selectbox(
        "Rendez-vous",
        list(a_cloturer),
        format_func=lambda i: (
            f"{format_date(a_cloturer[i]['date_rdv'])} {format_heure(a_cloturer[i]['heure_rdv'])} - "
            f"{a_cloturer[i]['patient_nom']}"
        ),
        key="rdv_a_cloturer",
    )
    colonne_honore, colonne_absent, _ = st.columns([2, 2, 3])
    nouveau_statut = None
    if colonne_honore.button("Marquer honoré", disabled=hors_ligne, key="marquer_honore"):
        nouveau_statut = "Honoré"
    if colonne_absent.button("Marquer absent", disabled=hors_ligne, key="marquer_absent"):
        nouveau_statut = "Absent"
    if nouveau_statut and appel(api_client.modifier_rdv, rdv_id, statut=nouveau_statut):
        st.session_state["_succes"] = f"Rendez-vous {rdv_id} marqué « {nouveau_statut} »."
        st.rerun()


# --------------------------------------------------------------------------------------
# Profil Direction
# --------------------------------------------------------------------------------------


def page_tableau_de_bord(listes: dict) -> None:
    st.header("Tableau de bord")
    medecins = listes["medecins"]
    colonne_periode, colonne_specialite, colonne_medecin = st.columns(3)
    jour_courant = aujourdhui()
    periode = colonne_periode.date_input(
        "Période",
        value=(jour_courant - timedelta(days=365), jour_courant),
        format="DD/MM/YYYY",
        key="periode_direction",
    )
    specialite = colonne_specialite.selectbox(
        "Spécialité", ["Toutes"] + sorted({m["specialite"] for m in medecins}), key="specialite_direction"
    )
    medecins_filtres = {m["id"]: m for m in medecins if specialite == "Toutes" or m["specialite"] == specialite}
    medecin_id = colonne_medecin.selectbox(
        "Médecin",
        [None] + list(medecins_filtres),
        format_func=lambda i: "Tous" if i is None else medecins_filtres[i]["nom"],
        key="medecin_direction",
    )
    if not isinstance(periode, (tuple, list)) or len(periode) != 2:
        st.info("Sélectionnez une date de début et une date de fin.")
        return
    date_debut, date_fin = periode
    filtre_specialite = None if specialite == "Toutes" else specialite

    kpi = appel(api_client.indicateurs, date_debut, date_fin, filtre_specialite, medecin_id)
    if kpi is None:
        st.caption("Les indicateurs ne peuvent pas être affichés tant que le service est indisponible.")
        return
    colonnes = st.columns(5)
    colonnes[0].metric("Rendez-vous", kpi["total_rdv"])
    colonnes[1].metric("Honorés", kpi["honores"])
    colonnes[2].metric("Absents", kpi["absents"])
    colonnes[3].metric("Taux d'absence", format_pourcentage(kpi["taux_absence_pct"]))
    colonnes[4].metric("Annulés", kpi["repartition_statuts"]["Annulé"])
    st.caption(
        f"Taux d'absence = absents / (honorés + absents) = {kpi['absents']} / {kpi['base_calcul_absence']}. "
        "Les rendez-vous planifiés, confirmés et annulés sont exclus du calcul."
    )

    st.subheader("Taux d'absence par spécialité")
    if specialite == "Toutes":
        par_specialite = appel(api_client.absence_par_specialite, date_debut, date_fin, medecin_id)
        if par_specialite is not None:
            tableau(
                [
                    {
                        "Spécialité": s["specialite"],
                        "Rendez-vous": s["total_rdv"],
                        "Honorés": s["honores"],
                        "Absents": s["absents"],
                        "Taux d'absence (%)": s["taux_absence_pct"],
                    }
                    for s in par_specialite
                ]
            )
            if par_specialite:
                # Apostrophe typographique volontaire : une apostrophe droite dans le nom d'une colonne
                # empêche l'affichage du graphique.
                st.bar_chart(
                    pd.DataFrame(
                        {"Taux d’absence (%)": [s["taux_absence_pct"] for s in par_specialite]},
                        index=[s["specialite"] for s in par_specialite],
                    )
                )
    else:
        st.caption("La comparaison entre spécialités s'affiche lorsque « Toutes » est sélectionné.")

    st.subheader("Évolution mensuelle")
    mensuel = appel(api_client.absence_mensuelle, date_debut, date_fin, filtre_specialite, medecin_id)
    if mensuel is not None:
        if not mensuel:
            st.info("Aucun rendez-vous sur cette période.")
        else:
            donnees = pd.DataFrame(mensuel).set_index("periode")
            st.caption("Taux d'absence mensuel (%)")
            # Un mois sans rendez-vous honoré ni absent n'a pas de taux (non calculable) : il n'est pas tracé,
            # afin de ne pas être confondu avec un taux de 0 %.
            taux = donnees[["taux_absence_pct"]].dropna()
            st.line_chart(taux.rename(columns={"taux_absence_pct": "Taux d’absence (%)"}))
            if len(taux) < len(donnees):
                st.caption("Les mois sans rendez-vous honoré ni absent n'ont pas de taux calculable et ne sont pas tracés.")
            st.caption("Nombre de rendez-vous par mois")
            st.bar_chart(donnees[["total_rdv"]].rename(columns={"total_rdv": "Rendez-vous"}))


# --------------------------------------------------------------------------------------
# Point d'entrée
# --------------------------------------------------------------------------------------


def main() -> None:
    listes, hors_ligne = charger_referentiels(forcer=st.session_state.pop("_actualiser", False))
    if listes is None:
        st.title("MédiRDV")
        st.info(
            "Aucune donnée n'a pu être chargée. Vérifiez que l'API est démarrée "
            "(commande : uvicorn backend.main:app), puis réessayez."
        )
        if st.button("Réessayer", key="reessayer"):
            st.rerun()
        st.stop()

    with st.sidebar:
        st.title("MédiRDV")
        st.caption(NOM_CLINIQUE)
        profil = st.radio("Profil", PROFILS, key="profil")
        if profil == "Agent d'accueil":
            agent_id = st.selectbox("Agent", [a["id"] for a in listes["agents"]], key="agent")
            page = st.radio("Menu", ["Nouveau rendez-vous", "Rendez-vous d'un patient"], key="menu_agent")
        elif profil == "Médecin":
            medecins = {m["id"]: m for m in listes["medecins"]}
            medecin_id = st.selectbox(
                "Médecin", list(medecins), format_func=lambda i: medecins[i]["nom"], key="medecin_connecte"
            )
        if st.button("Actualiser les listes", key="actualiser"):
            st.session_state["_actualiser"] = True
            st.rerun()

    if profil == "Agent d'accueil":
        if page == "Nouveau rendez-vous":
            page_nouveau_rdv(listes, agent_id, hors_ligne)
        else:
            page_rendez_vous_patient(hors_ligne)
    elif profil == "Médecin":
        page_planning_medecin(medecins[medecin_id], hors_ligne)
    else:
        page_tableau_de_bord(listes)


main()
