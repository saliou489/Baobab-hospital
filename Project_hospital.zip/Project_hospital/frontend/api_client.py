"""Client HTTP centralisé de l'interface MédiRDV.

Tous les appels à l'API passent par ce module. Chaque appel est encapsulé dans un bloc
``try/except requests.exceptions.RequestException`` et toute défaillance (serveur arrêté,
délai dépassé, erreur renvoyée par l'API) est convertie en une seule exception, ``ErreurApi``,
que l'interface affiche sous forme de bannière sobre.

Configuration par variables d'environnement :
- MEDIRDV_API_URL : adresse de l'API (défaut : http://127.0.0.1:8000) ;
- MEDIRDV_API_DELAI_S : délai d'attente maximal d'une requête en secondes (défaut : 10).
"""
import logging
import os
from datetime import date, time
from typing import Any

import requests

logger = logging.getLogger(__name__)

URL_API = os.getenv("MEDIRDV_API_URL", "http://127.0.0.1:8000").rstrip("/")
DELAI_ATTENTE_S = float(os.getenv("MEDIRDV_API_DELAI_S", "10"))


class ErreurApi(Exception):
    """Erreur renvoyée par l'API ou indisponibilité du serveur.

    Attributs :
    - message : texte en français destiné à l'utilisateur ;
    - code_erreur : code renvoyé par l'API (ex. CONFLIT_MEDECIN) ou code local ;
    - statut_http : code HTTP, ou None si le serveur n'a pas répondu ;
    - indisponible : True si le serveur est injoignable ou trop lent (repli à prévoir).
    """

    def __init__(
        self,
        message: str,
        code_erreur: str = "ERREUR_API",
        statut_http: int | None = None,
        indisponible: bool = False,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code_erreur = code_erreur
        self.statut_http = statut_http
        self.indisponible = indisponible


def _nettoyer(donnees: dict[str, Any]) -> dict[str, Any]:
    """Retire les valeurs nulles et convertit dates et heures au format attendu par l'API."""
    resultat: dict[str, Any] = {}
    for cle, valeur in donnees.items():
        if valeur is None:
            continue
        if isinstance(valeur, date):
            valeur = valeur.isoformat()
        elif isinstance(valeur, time):
            valeur = valeur.strftime("%H:%M")
        resultat[cle] = valeur
    return resultat


def _appeler(
    methode: str,
    chemin: str,
    *,
    params: dict[str, Any] | None = None,
    corps: dict[str, Any] | None = None,
) -> Any:
    """Émet une requête vers l'API et retourne le JSON de la réponse, ou lève ErreurApi."""
    url = f"{URL_API}{chemin}"
    try:
        reponse = requests.request(
            methode,
            url,
            params=_nettoyer(params) if params else None,
            json=_nettoyer(corps) if corps is not None else None,
            timeout=DELAI_ATTENTE_S,
        )
    except requests.exceptions.Timeout as exc:
        logger.warning("Délai dépassé pour %s %s", methode, chemin)
        raise ErreurApi(
            "Le serveur met trop de temps à répondre.", "API_DELAI_DEPASSE", indisponible=True
        ) from exc
    except requests.exceptions.ConnectionError as exc:
        logger.warning("Serveur injoignable pour %s %s", methode, chemin)
        raise ErreurApi(
            f"Le serveur MédiRDV ne répond pas ({URL_API}).", "API_INJOIGNABLE", indisponible=True
        ) from exc
    except requests.exceptions.RequestException as exc:
        logger.warning("Échec de la requête %s %s : %s", methode, chemin, type(exc).__name__)
        raise ErreurApi("La requête vers le serveur a échoué.", "API_REQUETE_ECHOUEE", indisponible=True) from exc

    if reponse.ok:
        try:
            return reponse.json()
        except ValueError as exc:
            raise ErreurApi("Réponse inattendue du serveur.", "REPONSE_INVALIDE", reponse.status_code) from exc

    # Réponse d'erreur : l'API renvoie {"detail": ..., "code_erreur": ...}.
    try:
        corps_erreur = reponse.json()
        detail = str(corps_erreur.get("detail") or "")
        code = str(corps_erreur.get("code_erreur") or "ERREUR_HTTP")
    except (ValueError, AttributeError):
        detail, code = "", "ERREUR_HTTP"
    if not detail:
        detail = f"Le serveur a répondu par une erreur (code HTTP {reponse.status_code})."
    raise ErreurApi(detail, code, reponse.status_code, indisponible=reponse.status_code in (502, 503, 504))


# --------------------------------------------------------------------------------------
# Système et référentiels
# --------------------------------------------------------------------------------------


def verifier_sante() -> dict:
    return _appeler("GET", "/sante")


def lister_agents() -> list[dict]:
    return _appeler("GET", "/referentiels/agents")


def lister_medecins(specialite: str | None = None) -> list[dict]:
    return _appeler("GET", "/referentiels/medecins", params={"specialite": specialite})


# --------------------------------------------------------------------------------------
# Patients
# --------------------------------------------------------------------------------------


def rechercher_patients(texte: str, limite: int = 20) -> dict:
    return _appeler("GET", "/patients", params={"q": texte, "limite": limite})


def obtenir_patient(patient_id: str) -> dict:
    return _appeler("GET", f"/patients/{patient_id}")


def creer_patient(
    nom: str,
    prenom: str,
    sexe: str,
    date_naissance: date | None,
    telephone: str,
    quartier: str | None = None,
) -> dict:
    return _appeler(
        "POST",
        "/patients",
        corps={
            "nom": nom,
            "prenom": prenom,
            "sexe": sexe,
            "date_naissance": date_naissance,
            "telephone": telephone,
            "quartier": quartier or None,
        },
    )


def historique_patient(patient_id: str) -> dict:
    return _appeler("GET", f"/patients/{patient_id}/historique")


# --------------------------------------------------------------------------------------
# Rendez-vous
# --------------------------------------------------------------------------------------


def lister_rdv(
    *,
    medecin_id: str | None = None,
    patient_id: str | None = None,
    specialite: str | None = None,
    statuts: list[str] | None = None,
    date_debut: date | None = None,
    date_fin: date | None = None,
    limite: int = 500,
) -> dict:
    params: dict[str, Any] = {
        "medecin_id": medecin_id,
        "patient_id": patient_id,
        "specialite": specialite,
        "date_debut": date_debut,
        "date_fin": date_fin,
        "limite": limite,
    }
    if statuts:
        params["statuts"] = statuts  # requests répète le paramètre pour chaque valeur
    return _appeler("GET", "/rdv", params=params)


def creer_rdv(
    patient_id: str,
    medecin_id: str,
    agent_id: str,
    date_rdv: date,
    heure_rdv: time,
    canal: str | None = None,
) -> dict:
    return _appeler(
        "POST",
        "/rdv",
        corps={
            "patient_id": patient_id,
            "medecin_id": medecin_id,
            "agent_id": agent_id,
            "date_rdv": date_rdv,
            "heure_rdv": heure_rdv,
            "canal": canal,
        },
    )


def modifier_rdv(
    rdv_id: str,
    *,
    statut: str | None = None,
    motif_annulation: str | None = None,
    date_rdv: date | None = None,
    heure_rdv: time | None = None,
) -> dict:
    return _appeler(
        "PATCH",
        f"/rdv/{rdv_id}",
        corps={
            "statut": statut,
            "motif_annulation": motif_annulation,
            "date_rdv": date_rdv,
            "heure_rdv": heure_rdv,
        },
    )


# --------------------------------------------------------------------------------------
# Statistiques
# --------------------------------------------------------------------------------------


def indicateurs(
    date_debut: date | None = None,
    date_fin: date | None = None,
    specialite: str | None = None,
    medecin_id: str | None = None,
) -> dict:
    return _appeler(
        "GET",
        "/stats/kpi",
        params={"date_debut": date_debut, "date_fin": date_fin, "specialite": specialite, "medecin_id": medecin_id},
    )


def absence_par_specialite(
    date_debut: date | None = None, date_fin: date | None = None, medecin_id: str | None = None
) -> list[dict]:
    return _appeler(
        "GET",
        "/stats/absence/par-specialite",
        params={"date_debut": date_debut, "date_fin": date_fin, "medecin_id": medecin_id},
    )


def absence_mensuelle(
    date_debut: date | None = None,
    date_fin: date | None = None,
    specialite: str | None = None,
    medecin_id: str | None = None,
) -> list[dict]:
    return _appeler(
        "GET",
        "/stats/absence/mensuelle",
        params={"date_debut": date_debut, "date_fin": date_fin, "specialite": specialite, "medecin_id": medecin_id},
    )
