"""Application FastAPI MédiRDV.

Lancement (depuis la racine du projet) :

    uvicorn backend.main:app --reload

La documentation interactive (Swagger) est disponible sur /docs.
"""
import logging
import os
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI
from sqlalchemy import text
from sqlalchemy.orm import Session

from backend.database import engine, get_db, initialiser_base
from backend.exceptions import enregistrer_gestionnaires
from backend.routes import patients, rdv, stats

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s : %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def cycle_de_vie(_application: FastAPI):
    """Au démarrage : création des tables manquantes (aucune donnée n'est écrasée)."""
    initialiser_base()
    logger.info("Base de données prête (moteur : %s).", engine.dialect.name)
    yield


app = FastAPI(
    title="MédiRDV - API de gestion des rendez-vous",
    version="1.0.0",
    description=(
        "API de prise et de suivi des rendez-vous médicaux. "
        "Toutes les erreurs sont renvoyées au format {\"detail\": ..., \"code_erreur\": ...}."
    ),
    lifespan=cycle_de_vie,
)

enregistrer_gestionnaires(app)

app.include_router(rdv.router)
app.include_router(rdv.router_referentiels)
app.include_router(patients.router)
app.include_router(stats.router)


@app.get("/sante", tags=["Système"], summary="Contrôle de disponibilité de l'API et de la base")
def sante(db: Session = Depends(get_db)) -> dict[str, str]:
    """Répond « ok » si l'API et la base de données sont joignables (sinon erreur 500 au format uniforme)."""
    db.execute(text("SELECT 1"))
    return {"statut": "ok", "base_de_donnees": "disponible"}
