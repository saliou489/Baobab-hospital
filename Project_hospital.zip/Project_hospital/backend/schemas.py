"""Schémas Pydantic (entrées et sorties de l'API) avec validateurs stricts.

Convention : les messages des validateurs sont rédigés en français et commencent par une
minuscule ; le gestionnaire d'erreurs (exceptions.py) y ajoute le nom du champ concerné
ou met la première lettre en majuscule.
"""
import re
import unicodedata
from datetime import date, datetime, time

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from pydantic_core import PydanticCustomError

from backend.models import (
    PATRON_ID_AGENT,
    PATRON_ID_MEDECIN,
    PATRON_ID_PATIENT,
    Canal,
    MotifAnnulation,
    Sexe,
    StatutRdv,
    aujourdhui,
    maintenant,
)

# --------------------------------------------------------------------------------------
# Fonctions de validation réutilisées (schémas et import du CSV)
# --------------------------------------------------------------------------------------

# Numéro sénégalais : 9 chiffres commençant par 77, 78, 76, 70, 75 ou 33.
MOTIF_TELEPHONE = re.compile(r"^(77|78|76|70|75|33)\d{7}$")
# Lettres (accents compris), séparées par un espace, une apostrophe ou un tiret.
MOTIF_NOM = re.compile(r"^[^\W\d_]+(?:[ '’\-][^\W\d_]+)*$")


def valider_telephone(valeur: str) -> str:
    """Valide un numéro de téléphone sénégalais et le retourne tel quel (9 chiffres)."""
    texte = str(valeur).strip()
    if not MOTIF_TELEPHONE.fullmatch(texte):
        raise ValueError(
            "numéro invalide : 9 chiffres sans espace, commençant par 77, 78, 76, 70, 75 ou 33 "
            "(exemple : 771234567)"
        )
    return texte


def normaliser_nom(valeur: str) -> str:
    """Nettoie un nom ou un prénom : espaces superflus retirés ; majuscule initiale si la saisie est
    entièrement en majuscules ou en minuscules. Lève ValueError si le texte n'est pas un nom."""
    propre = " ".join(unicodedata.normalize("NFC", str(valeur)).split())
    if not propre:
        raise ValueError("ne peut pas être vide")
    if propre.isupper() or propre.islower():
        propre = propre.title()
    if not MOTIF_NOM.fullmatch(propre):
        raise ValueError("ne peut contenir que des lettres, espaces, tirets et apostrophes")
    return propre


def verifier_date_naissance(valeur: date) -> date:
    """La date de naissance ne peut pas être dans le futur."""
    if valeur > aujourdhui():
        raise ValueError("la date de naissance ne peut pas être dans le futur")
    return valeur


# --------------------------------------------------------------------------------------
# Classes de base
# --------------------------------------------------------------------------------------


class SchemaEntree(BaseModel):
    """Entrée stricte : champs inconnus refusés, espaces superflus retirés."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class SchemaSortie(BaseModel):
    """Sortie construite à partir d'objets ORM."""

    model_config = ConfigDict(from_attributes=True)


# --------------------------------------------------------------------------------------
# Patients
# --------------------------------------------------------------------------------------


class PatientCreation(SchemaEntree):
    """Création d'une fiche patient."""

    nom: str = Field(min_length=1, max_length=80)
    prenom: str = Field(min_length=1, max_length=80)
    sexe: Sexe
    date_naissance: date
    telephone: str
    quartier: str | None = Field(default=None, max_length=60)

    @field_validator("nom", "prenom")
    @classmethod
    def _nom_valide(cls, valeur: str) -> str:
        return normaliser_nom(valeur)

    @field_validator("date_naissance")
    @classmethod
    def _naissance_valide(cls, valeur: date) -> date:
        return verifier_date_naissance(valeur)

    @field_validator("telephone")
    @classmethod
    def _telephone_valide(cls, valeur: str) -> str:
        return valider_telephone(valeur)

    @field_validator("quartier", mode="before")
    @classmethod
    def _quartier_vide(cls, valeur):
        if isinstance(valeur, str) and not valeur.strip():
            return None
        return valeur


class PatientMiseAJour(SchemaEntree):
    """Modification partielle d'une fiche patient."""

    nom: str | None = Field(default=None, min_length=1, max_length=80)
    prenom: str | None = Field(default=None, min_length=1, max_length=80)
    date_naissance: date | None = None
    telephone: str | None = None
    quartier: str | None = Field(default=None, max_length=60)

    @field_validator("nom", "prenom")
    @classmethod
    def _nom_valide(cls, valeur: str | None) -> str | None:
        return None if valeur is None else normaliser_nom(valeur)

    @field_validator("date_naissance")
    @classmethod
    def _naissance_valide(cls, valeur: date | None) -> date | None:
        return None if valeur is None else verifier_date_naissance(valeur)

    @field_validator("telephone")
    @classmethod
    def _telephone_valide(cls, valeur: str | None) -> str | None:
        return None if valeur is None else valider_telephone(valeur)

    @model_validator(mode="after")
    def _au_moins_un_champ(self) -> "PatientMiseAJour":
        if not self.model_fields_set:
            raise ValueError("aucune modification n'a été fournie.")
        return self


class PatientLecture(SchemaSortie):
    """Fiche patient renvoyée par l'API."""

    id: str
    nom: str
    prenom: str
    sexe: Sexe
    date_naissance: date | None
    telephone: str | None
    quartier: str | None


class AlerteRecidiviste(BaseModel):
    """Résultat de la règle RG-08."""

    actif: bool
    nb_absences: int
    seuil: int
    periode_mois: int
    message: str | None = None


class PatientDetail(PatientLecture):
    """Fiche patient accompagnée de l'alerte RG-08."""

    alerte_recidiviste: AlerteRecidiviste


class ListePatients(BaseModel):
    """Page de résultats de recherche de patients."""

    total: int
    limite: int
    decalage: int
    elements: list[PatientLecture]


# --------------------------------------------------------------------------------------
# Rendez-vous
# --------------------------------------------------------------------------------------


class RdvCreation(SchemaEntree):
    """Création d'un rendez-vous (statut initial : Planifié)."""

    patient_id: str = Field(pattern=PATRON_ID_PATIENT)
    medecin_id: str = Field(pattern=PATRON_ID_MEDECIN)
    agent_id: str = Field(pattern=PATRON_ID_AGENT)
    # Si elle est absente, la date de prise est la date du jour.
    date_prise: date | None = None
    date_rdv: date
    heure_rdv: time
    canal: Canal | None = None

    @field_validator("heure_rdv")
    @classmethod
    def _heure_sans_secondes(cls, valeur: time) -> time:
        if valeur.second or valeur.microsecond or valeur.tzinfo is not None:
            raise ValueError("heure invalide : format attendu HH:MM")
        return valeur

    @model_validator(mode="after")
    def _verifier_dates(self) -> "RdvCreation":
        # 1. Pas de rendez-vous dans le passé (message testé en premier : c'est le plus parlant
        #    pour l'agent lorsque la date de prise est celle du jour par défaut).
        if datetime.combine(self.date_rdv, self.heure_rdv) < maintenant():
            raise ValueError("impossible de créer un rendez-vous à une date ou une heure passée.")
        if self.date_prise is None:
            self.date_prise = aujourdhui()
        # 2. date_prise <= date_rdv.
        if self.date_prise > self.date_rdv:
            raise ValueError(
                "la date de prise du rendez-vous ne peut pas être postérieure à la date du rendez-vous."
            )
        # 3. On ne peut pas avoir pris rendez-vous dans le futur.
        if self.date_prise > aujourdhui():
            raise ValueError("la date de prise du rendez-vous ne peut pas être dans le futur.")
        return self


class RdvMiseAJour(SchemaEntree):
    """Modification d'un rendez-vous : changement de statut, annulation ou reprogrammation."""

    date_rdv: date | None = None
    heure_rdv: time | None = None
    statut: StatutRdv | None = None
    motif_annulation: MotifAnnulation | None = None

    @field_validator("motif_annulation", mode="before")
    @classmethod
    def _motif_vide(cls, valeur):
        """Un motif vide ou composé d'espaces équivaut à un motif absent."""
        if isinstance(valeur, str) and not valeur.strip():
            return None
        return valeur

    @field_validator("heure_rdv")
    @classmethod
    def _heure_sans_secondes(cls, valeur: time | None) -> time | None:
        if valeur is not None and (valeur.second or valeur.microsecond or valeur.tzinfo is not None):
            raise ValueError("heure invalide : format attendu HH:MM")
        return valeur

    @model_validator(mode="after")
    def _verifier_coherence(self) -> "RdvMiseAJour":
        if not self.model_fields_set:
            raise ValueError("aucune modification n'a été fournie.")
        # RG-05 : un rendez-vous ne peut être annulé qu'avec un motif. Ces deux types d'erreur
        # sont convertis en HTTP 400 (règle métier) par le gestionnaire d'erreurs.
        if self.statut == StatutRdv.ANNULE and self.motif_annulation is None:
            raise PydanticCustomError(
                "motif_annulation_manquant",
                "un motif d'annulation est obligatoire pour annuler un rendez-vous "
                "(patient, médecin, clinique ou autre).",
            )
        if self.motif_annulation is not None and self.statut != StatutRdv.ANNULE:
            raise PydanticCustomError(
                "motif_sans_annulation",
                "un motif d'annulation ne peut être renseigné que pour le statut « Annulé ».",
            )
        if self.statut == StatutRdv.ANNULE and (self.date_rdv is not None or self.heure_rdv is not None):
            raise ValueError("une annulation ne peut pas être combinée à un changement de date ou d'heure.")
        return self


class RdvLecture(SchemaSortie):
    """Rendez-vous renvoyé par l'API."""

    id: str
    patient_id: str
    patient_nom: str
    medecin_id: str
    medecin_nom: str
    specialite: str
    agent_id: str
    date_prise: date
    date_rdv: date
    heure_rdv: time
    duree_min: int
    statut: StatutRdv
    confirme: bool | None
    canal: Canal | None
    motif_annulation: MotifAnnulation | None


class ListeRdv(BaseModel):
    """Page de résultats de rendez-vous."""

    total: int
    limite: int
    decalage: int
    elements: list[RdvLecture]


class Avertissement(BaseModel):
    """Message d'alerte non bloquant destiné à l'agent."""

    code: str
    message: str


class ReponseCreationRdv(BaseModel):
    """Réponse à la création d'un rendez-vous : le rendez-vous et d'éventuels avertissements."""

    rdv: RdvLecture
    avertissements: list[Avertissement]


class HistoriquePatient(BaseModel):
    """Historique des rendez-vous d'un patient et indicateurs associés."""

    patient_id: str
    total_rdv: int
    honores: int
    absents: int
    annules: int
    taux_absence_pct: float | None
    alerte_recidiviste: AlerteRecidiviste
    rendez_vous: list[RdvLecture]


# --------------------------------------------------------------------------------------
# Référentiels
# --------------------------------------------------------------------------------------


class MedecinLecture(SchemaSortie):
    """Médecin renvoyé par l'API."""

    id: str
    nom: str
    specialite: str
    duree_consultation_min: int


class AgentLecture(SchemaSortie):
    """Agent renvoyé par l'API."""

    id: str


# --------------------------------------------------------------------------------------
# Statistiques
# --------------------------------------------------------------------------------------


class PeriodeFiltre(BaseModel):
    """Filtres appliqués à un calcul statistique."""

    date_debut: date | None = None
    date_fin: date | None = None
    specialite: str | None = None
    medecin_id: str | None = None


class KpiGlobaux(BaseModel):
    """Indicateurs clés sur la période filtrée."""

    filtres: PeriodeFiltre
    total_rdv: int
    repartition_statuts: dict[str, int]
    honores: int
    absents: int
    base_calcul_absence: int
    taux_absence_pct: float | None


class AbsenceSpecialite(BaseModel):
    """Taux d'absence (RG-09) d'une spécialité."""

    specialite: str
    total_rdv: int
    honores: int
    absents: int
    taux_absence_pct: float | None


class AbsenceMensuelle(BaseModel):
    """Volume et taux d'absence (RG-09) d'un mois."""

    periode: str
    total_rdv: int
    honores: int
    absents: int
    taux_absence_pct: float | None


class ErreurReponse(BaseModel):
    """Format uniforme des erreurs de l'API."""

    detail: str
    code_erreur: str
