"""Paquet backend de MédiRDV (API FastAPI, modèles et import de données)."""
