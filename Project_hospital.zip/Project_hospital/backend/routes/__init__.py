"""Routes de l'API MédiRDV (rendez-vous, patients, statistiques)."""
