"""Endpoints des rendez-vous (CRUD) et règles RG-01, RG-02 et RG-05.

Il n'y a pas de suppression physique : annuler un rendez-vous consiste à passer son statut à
« Annulé » avec un motif (RG-05), ce qui libère immédiatement le créneau.
"""
import logging
from datetime import date, datetime, time, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from backend.database import ecrire_avec_reessai, get_db
from backend.exceptions import (
    ConflitError,
    DonneesInvalidesError,
    RegleMetierError,
    RessourceIntrouvableError,
)
from backend.models import (
    PREFIXE_RDV,
    STATUTS_ACTIFS,
    STATUTS_CLOS,
    TRANSITIONS_STATUT,
    Agent,
    Medecin,
    Patient,
    RendezVous,
    StatutRdv,
    aujourdhui,
    maintenant,
    prochain_identifiant,
)
from backend.routes.patients import evaluer_alerte_recidiviste, obtenir_patient_ou_404
from backend.schemas import (
    AgentLecture,
    Avertissement,
    ErreurReponse,
    ListeRdv,
    MedecinLecture,
    RdvCreation,
    RdvLecture,
    RdvMiseAJour,
    ReponseCreationRdv,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/rdv", tags=["Rendez-vous"])
router_referentiels = APIRouter(prefix="/referentiels", tags=["Référentiels"])

REPONSES_ERREURS = {
    400: {"model": ErreurReponse, "description": "Règle métier violée (ex. motif d'annulation manquant)"},
    404: {"model": ErreurReponse, "description": "Patient, médecin, agent ou rendez-vous inexistant"},
    409: {"model": ErreurReponse, "description": "Conflit d'agenda (médecin ou patient déjà pris)"},
    422: {"model": ErreurReponse, "description": "Données invalides (date, heure, identifiant)"},
    500: {"model": ErreurReponse, "description": "Erreur interne"},
}


# --------------------------------------------------------------------------------------
# Accès aux ressources et règles RG-01 / RG-02
# --------------------------------------------------------------------------------------


def _obtenir_rdv(db: Session, rdv_id: str) -> RendezVous:
    rdv = db.get(RendezVous, rdv_id)
    if rdv is None:
        raise RessourceIntrouvableError(f"Rendez-vous {rdv_id} introuvable.", "RDV_INTROUVABLE")
    return rdv


def _obtenir_medecin(db: Session, medecin_id: str) -> Medecin:
    medecin = db.get(Medecin, medecin_id)
    if medecin is None:
        raise RessourceIntrouvableError(f"Médecin {medecin_id} introuvable.", "MEDECIN_INTROUVABLE")
    return medecin


def _obtenir_agent(db: Session, agent_id: str) -> Agent:
    agent = db.get(Agent, agent_id)
    if agent is None:
        raise RessourceIntrouvableError(f"Agent {agent_id} introuvable.", "AGENT_INTROUVABLE")
    return agent


def _libelle_creneau(rdv: RendezVous) -> str:
    return f"le {rdv.debut:%d/%m/%Y} de {rdv.debut:%H:%M} à {rdv.fin:%H:%M}"


def verifier_conflits(
    db: Session,
    *,
    medecin: Medecin,
    patient: Patient,
    debut: datetime,
    fin: datetime,
    exclure_rdv_id: str | None = None,
) -> None:
    """RG-01 puis RG-02 : lève ConflitError (HTTP 409) si l'intervalle chevauche un rendez-vous actif.

    - RG-01 : un médecin ne peut pas avoir deux rendez-vous actifs au même moment ;
    - RG-02 : un patient ne peut pas avoir deux rendez-vous actifs simultanés, tous médecins confondus.

    Sont actifs les rendez-vous « Planifié », « Confirmé » ou « Honoré » : un rendez-vous annulé
    libère son créneau. ``exclure_rdv_id`` permet d'ignorer le rendez-vous en cours de déplacement.
    """
    criteres = [
        RendezVous.statut.in_(STATUTS_ACTIFS),
        RendezVous.debut < fin,
        RendezVous.fin > debut,
    ]
    if exclure_rdv_id is not None:
        criteres.append(RendezVous.id != exclure_rdv_id)

    conflit_medecin = db.scalars(
        select(RendezVous)
        .where(RendezVous.medecin_id == medecin.id, *criteres)
        .order_by(RendezVous.debut)
        .limit(1)
    ).first()
    if conflit_medecin is not None:
        raise ConflitError(
            f"Conflit d'agenda : {medecin.nom} a déjà un rendez-vous {_libelle_creneau(conflit_medecin)}.",
            "CONFLIT_MEDECIN",
        )

    conflit_patient = db.scalars(
        select(RendezVous)
        .where(RendezVous.patient_id == patient.id, *criteres)
        .order_by(RendezVous.debut)
        .limit(1)
    ).first()
    if conflit_patient is not None:
        raise ConflitError(
            f"Conflit patient : {patient.nom} {patient.prenom} a déjà un rendez-vous "
            f"{_libelle_creneau(conflit_patient)} avec {conflit_patient.medecin.nom}.",
            "CONFLIT_PATIENT",
        )


# --------------------------------------------------------------------------------------
# Rendez-vous
# --------------------------------------------------------------------------------------


@router.post(
    "",
    response_model=ReponseCreationRdv,
    status_code=201,
    summary="Créer un rendez-vous",
    responses=REPONSES_ERREURS,
)
def creer_rdv(donnees: RdvCreation, db: Session = Depends(get_db)) -> ReponseCreationRdv:
    """Crée un rendez-vous au statut « Planifié ».

    Les vérifications RG-01 et RG-02 sont faites en base, dans la transaction, avant l'insertion.
    La réponse peut contenir un avertissement RG-08 (patient récidiviste) qui ne bloque pas la création.
    """

    def operation() -> RendezVous:
        patient = obtenir_patient_ou_404(db, donnees.patient_id)
        medecin = _obtenir_medecin(db, donnees.medecin_id)
        agent = _obtenir_agent(db, donnees.agent_id)
        if not medecin.actif:
            raise RegleMetierError(f"{medecin.nom} n'est plus actif : aucun rendez-vous possible.", "MEDECIN_INACTIF")
        if not agent.actif:
            raise RegleMetierError(f"L'agent {agent.id} n'est plus actif.", "AGENT_INACTIF")

        debut = datetime.combine(donnees.date_rdv, donnees.heure_rdv)
        fin = debut + timedelta(minutes=medecin.duree_consultation_min)
        verifier_conflits(db, medecin=medecin, patient=patient, debut=debut, fin=fin)

        rdv = RendezVous(
            id=prochain_identifiant(db, RendezVous, PREFIXE_RDV, 5),
            patient=patient,
            medecin=medecin,
            agent=agent,
            date_prise=donnees.date_prise,
            debut=debut,
            fin=fin,
            statut=StatutRdv.PLANIFIE,
            confirme=False,
            canal=donnees.canal,
        )
        db.add(rdv)
        db.flush()
        return rdv

    rdv = ecrire_avec_reessai(db, operation)
    logger.info("Rendez-vous %s créé.", rdv.id)

    avertissements: list[Avertissement] = []
    alerte = evaluer_alerte_recidiviste(db, rdv.patient_id)
    if alerte.actif and alerte.message:
        avertissements.append(Avertissement(code="PATIENT_RECIDIVISTE", message=alerte.message))
    return ReponseCreationRdv(rdv=RdvLecture.model_validate(rdv), avertissements=avertissements)


@router.get(
    "",
    response_model=ListeRdv,
    summary="Lister les rendez-vous",
    responses=REPONSES_ERREURS,
)
def lister_rdv(
    medecin_id: str | None = None,
    patient_id: str | None = None,
    specialite: str | None = None,
    statuts: Annotated[list[StatutRdv] | None, Query()] = None,
    date_debut: date | None = None,
    date_fin: date | None = None,
    limite: Annotated[int, Query(ge=1, le=1000)] = 100,
    decalage: Annotated[int, Query(ge=0)] = 0,
    db: Session = Depends(get_db),
) -> ListeRdv:
    """Liste filtrable (médecin, patient, spécialité, statuts, période), triée par date croissante."""
    if date_debut and date_fin and date_debut > date_fin:
        raise DonneesInvalidesError(
            "La date de début doit être antérieure ou égale à la date de fin.", "PERIODE_INVALIDE"
        )
    filtres: list = []
    if medecin_id:
        filtres.append(RendezVous.medecin_id == medecin_id)
    if patient_id:
        filtres.append(RendezVous.patient_id == patient_id)
    if specialite:
        filtres.append(RendezVous.medecin_id.in_(select(Medecin.id).where(Medecin.specialite == specialite)))
    if statuts:
        filtres.append(RendezVous.statut.in_(statuts))
    if date_debut:
        filtres.append(RendezVous.debut >= datetime.combine(date_debut, time.min))
    if date_fin:
        filtres.append(RendezVous.debut < datetime.combine(date_fin + timedelta(days=1), time.min))

    total = int(db.scalar(select(func.count()).select_from(RendezVous).where(*filtres)) or 0)
    rendez_vous = db.scalars(
        select(RendezVous).where(*filtres).order_by(RendezVous.debut, RendezVous.id).limit(limite).offset(decalage)
    ).all()
    return ListeRdv(
        total=total,
        limite=limite,
        decalage=decalage,
        elements=[RdvLecture.model_validate(r) for r in rendez_vous],
    )


@router.get(
    "/{rdv_id}",
    response_model=RdvLecture,
    summary="Consulter un rendez-vous",
    responses=REPONSES_ERREURS,
)
def lire_rdv(rdv_id: str, db: Session = Depends(get_db)) -> RdvLecture:
    return RdvLecture.model_validate(_obtenir_rdv(db, rdv_id))


@router.patch(
    "/{rdv_id}",
    response_model=RdvLecture,
    summary="Modifier, reprogrammer ou annuler un rendez-vous",
    responses=REPONSES_ERREURS,
)
def modifier_rdv(rdv_id: str, donnees: RdvMiseAJour, db: Session = Depends(get_db)) -> RdvLecture:
    """Change le statut (Confirmé, Honoré, Absent, Annulé) ou reprogramme un rendez-vous.

    - RG-05 : le statut « Annulé » exige un motif (vérifié par le schéma, puis ici par défense en profondeur) ;
    - cycle de vie : un rendez-vous clos (Honoré, Absent, Annulé) ne peut plus être modifié, et
      « Honoré » / « Absent » ne se fixent qu'à partir du jour du rendez-vous ;
    - reprogrammation : le nouveau créneau repasse par les contrôles RG-01 et RG-02.
    """

    def operation() -> RendezVous:
        rdv = _obtenir_rdv(db, rdv_id)
        if rdv.statut in STATUTS_CLOS:
            raise RegleMetierError(
                f"Le rendez-vous {rdv.id} est clos (statut « {rdv.statut.value} ») et ne peut plus être modifié.",
                "RDV_CLOS",
            )

        nouveau_statut = donnees.statut if donnees.statut is not None else rdv.statut
        changement_statut = nouveau_statut != rdv.statut
        reprogrammation = donnees.date_rdv is not None or donnees.heure_rdv is not None
        if not changement_statut and not reprogrammation:
            raise DonneesInvalidesError(
                "Aucune modification effective : les valeurs fournies sont identiques à l'existant.",
                "AUCUNE_MODIFICATION",
            )

        # --- Contrôles de statut (aucune écriture tant que tout n'est pas validé) ----------
        if changement_statut:
            if nouveau_statut not in TRANSITIONS_STATUT[rdv.statut]:
                raise RegleMetierError(
                    f"Transition de statut non autorisée : « {rdv.statut.value} » vers « {nouveau_statut.value} ».",
                    "TRANSITION_STATUT_INVALIDE",
                )
            if nouveau_statut in (StatutRdv.HONORE, StatutRdv.ABSENT) and rdv.debut.date() > aujourdhui():
                raise RegleMetierError(
                    "Le statut « Honoré » ou « Absent » ne peut être fixé qu'à partir du jour du rendez-vous.",
                    "STATUT_FINAL_PREMATURE",
                )
            if nouveau_statut == StatutRdv.ANNULE and donnees.motif_annulation is None:
                raise RegleMetierError(
                    "Un motif d'annulation est obligatoire pour annuler un rendez-vous.",
                    "MOTIF_ANNULATION_MANQUANT",
                )
        if reprogrammation and nouveau_statut not in (StatutRdv.PLANIFIE, StatutRdv.CONFIRME):
            raise RegleMetierError(
                "Un rendez-vous ne peut être reprogrammé que s'il reste « Planifié » ou « Confirmé ».",
                "MODIFICATION_INCOHERENTE",
            )

        # --- Reprogrammation : nouveau créneau, contrôles puis RG-01 / RG-02 ----------------
        nouveau_debut = nouvelle_fin = None
        if reprogrammation:
            nouveau_debut = datetime.combine(
                donnees.date_rdv or rdv.debut.date(), donnees.heure_rdv or rdv.debut.time()
            )
            if nouveau_debut == rdv.debut and not changement_statut:
                raise DonneesInvalidesError(
                    "Aucune modification effective : le créneau demandé est celui déjà enregistré.",
                    "AUCUNE_MODIFICATION",
                )
            if nouveau_debut < maintenant():
                raise DonneesInvalidesError(
                    "Impossible de reprogrammer un rendez-vous à une date ou une heure passée.", "DATE_PASSEE"
                )
            if rdv.date_prise > nouveau_debut.date():
                raise DonneesInvalidesError(
                    "La nouvelle date ne peut pas précéder la date de prise du rendez-vous.", "DATE_INCOHERENTE"
                )
            nouvelle_fin = nouveau_debut + (rdv.fin - rdv.debut)
            verifier_conflits(
                db,
                medecin=rdv.medecin,
                patient=rdv.patient,
                debut=nouveau_debut,
                fin=nouvelle_fin,
                exclure_rdv_id=rdv.id,
            )

        # --- Application des changements ----------------------------------------------------
        if changement_statut:
            rdv.statut = nouveau_statut
            if nouveau_statut == StatutRdv.ANNULE:
                rdv.motif_annulation = donnees.motif_annulation
            elif nouveau_statut == StatutRdv.CONFIRME:
                rdv.confirme = True
        if nouveau_debut is not None:
            rdv.debut = nouveau_debut
            rdv.fin = nouvelle_fin
        db.flush()
        return rdv

    rdv = ecrire_avec_reessai(db, operation)
    logger.info("Rendez-vous %s modifié (statut : %s).", rdv.id, rdv.statut.value)
    return RdvLecture.model_validate(rdv)


# --------------------------------------------------------------------------------------
# Référentiels (listes nécessaires à la saisie)
# --------------------------------------------------------------------------------------


@router_referentiels.get(
    "/medecins",
    response_model=list[MedecinLecture],
    summary="Lister les médecins actifs",
    responses=REPONSES_ERREURS,
)
def lister_medecins(specialite: str | None = None, db: Session = Depends(get_db)) -> list[Medecin]:
    requete = select(Medecin).where(Medecin.actif.is_(True))
    if specialite:
        requete = requete.where(Medecin.specialite == specialite)
    return list(db.scalars(requete.order_by(Medecin.specialite, Medecin.nom)).all())


@router_referentiels.get(
    "/agents",
    response_model=list[AgentLecture],
    summary="Lister les agents d'accueil actifs",
    responses=REPONSES_ERREURS,
)
def lister_agents(db: Session = Depends(get_db)) -> list[Agent]:
    return list(db.scalars(select(Agent).where(Agent.actif.is_(True)).order_by(Agent.id)).all())
