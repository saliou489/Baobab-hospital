"""Modèles ORM, énumérations et constantes métier de MédiRDV.

Entités : Agent, Medecin, Patient, RendezVous.
Les identifiants sont des chaînes lisibles (PAT00480, MED014, AGT07, RDV01965),
identiques à celles du fichier source afin de conserver la traçabilité.
"""
import calendar
import enum
from datetime import date, datetime, time, timezone

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Date,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    String,
    func,
    select,
    text,
)
from sqlalchemy.orm import Mapped, Session, mapped_column, relationship

from backend.database import Base

# --------------------------------------------------------------------------------------
# Énumérations
# --------------------------------------------------------------------------------------


class StatutRdv(str, enum.Enum):
    """Statuts d'un rendez-vous (cycle de vie : cahier des charges, section 6.1)."""

    PLANIFIE = "Planifié"
    CONFIRME = "Confirmé"
    HONORE = "Honoré"
    ABSENT = "Absent"
    ANNULE = "Annulé"


class MotifAnnulation(str, enum.Enum):
    """Motifs d'annulation autorisés (RG-05)."""

    PATIENT = "Patient"
    MEDECIN = "Médecin"
    CLINIQUE = "Clinique"
    AUTRE = "Autre"


class Sexe(str, enum.Enum):
    """Sexe du patient."""

    FEMININ = "F"
    MASCULIN = "M"


class Canal(str, enum.Enum):
    """Canal de prise de rendez-vous."""

    TELEPHONE = "Téléphone"
    GUICHET = "Guichet"
    RECOMMANDATION = "Recommandation médecin"


# --------------------------------------------------------------------------------------
# Constantes métier
# --------------------------------------------------------------------------------------

PREFIXE_PATIENT = "PAT"
PREFIXE_MEDECIN = "MED"
PREFIXE_AGENT = "AGT"
PREFIXE_RDV = "RDV"

PATRON_ID_PATIENT = r"^PAT\d{5}$"
PATRON_ID_MEDECIN = r"^MED\d{3}$"
PATRON_ID_AGENT = r"^AGT\d{2}$"
PATRON_ID_RDV = r"^RDV\d{5}$"

# Durées de consultation autorisées, en minutes (cahier des charges, EF-01).
DUREES_AUTORISEES_MIN = (15, 20, 30)

# RG-08 : alerte à partir de 3 absences sur les 6 derniers mois.
SEUIL_ABSENCES_RECIDIVISTE = 3
PERIODE_RECIDIVISTE_MOIS = 6

# RG-01 / RG-02 : seuls les rendez-vous actifs occupent un créneau.
STATUTS_ACTIFS = (StatutRdv.PLANIFIE, StatutRdv.CONFIRME, StatutRdv.HONORE)
STATUTS_CLOS = (StatutRdv.HONORE, StatutRdv.ABSENT, StatutRdv.ANNULE)

# Cycle de vie (cahier des charges, section 6.1) : un statut clos est définitif et
# l'annulation n'est possible que depuis « Planifié » ou « Confirmé ».
TRANSITIONS_STATUT = {
    StatutRdv.PLANIFIE: {StatutRdv.CONFIRME, StatutRdv.HONORE, StatutRdv.ABSENT, StatutRdv.ANNULE},
    StatutRdv.CONFIRME: {StatutRdv.HONORE, StatutRdv.ABSENT, StatutRdv.ANNULE},
    StatutRdv.HONORE: set(),
    StatutRdv.ABSENT: set(),
    StatutRdv.ANNULE: set(),
}

# --------------------------------------------------------------------------------------
# Utilitaires de date et d'identifiant
# --------------------------------------------------------------------------------------


def maintenant() -> datetime:
    """Heure courante de Dakar (UTC+0 toute l'année), sans fuseau : cohérente avec les colonnes DateTime."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


def aujourdhui() -> date:
    """Date du jour à Dakar."""
    return maintenant().date()


def reculer_de_mois(reference: datetime, mois: int) -> datetime:
    """Retourne ``reference`` reculée de ``mois`` mois calendaires (jour ramené au dernier jour du mois si besoin)."""
    total = reference.year * 12 + (reference.month - 1) - mois
    annee, indice = divmod(total, 12)
    mois_cible = indice + 1
    dernier_jour = calendar.monthrange(annee, mois_cible)[1]
    return reference.replace(year=annee, month=mois_cible, day=min(reference.day, dernier_jour))


def prochain_identifiant(db: Session, modele, prefixe: str, largeur: int) -> str:
    """Calcule le prochain identifiant séquentiel d'un modèle (ex. RDV02016).

    Les identifiants ont une largeur fixe : l'ordre alphabétique est donc l'ordre numérique.
    """
    dernier = db.scalar(select(func.max(modele.id)).where(modele.id.like(f"{prefixe}%")))
    numero = int(dernier[len(prefixe):]) + 1 if dernier else 1
    return f"{prefixe}{numero:0{largeur}d}"


def _type_enum(classe: type[enum.Enum], nom: str) -> Enum:
    """Colonne texte contrainte (CHECK) qui stocke les valeurs françaises de l'énumération."""
    return Enum(
        classe,
        name=nom,
        native_enum=False,
        create_constraint=True,
        validate_strings=True,
        length=30,
        values_callable=lambda membres: [membre.value for membre in membres],
    )


# --------------------------------------------------------------------------------------
# Modèles
# --------------------------------------------------------------------------------------


class Agent(Base):
    """Agent d'accueil qui saisit les rendez-vous."""

    __tablename__ = "agents"

    id: Mapped[str] = mapped_column(String(10), primary_key=True)
    actif: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    rendez_vous: Mapped[list["RendezVous"]] = relationship(back_populates="agent")


class Medecin(Base):
    """Médecin et sa spécialité."""

    __tablename__ = "medecins"
    __table_args__ = (
        CheckConstraint("duree_consultation_min IN (15, 20, 30)", name="ck_medecin_duree"),
    )

    id: Mapped[str] = mapped_column(String(10), primary_key=True)
    nom: Mapped[str] = mapped_column(String(120), nullable=False)
    specialite: Mapped[str] = mapped_column(String(60), nullable=False, index=True)
    # Durée d'une consultation, utilisée pour calculer l'heure de fin d'un nouveau rendez-vous.
    duree_consultation_min: Mapped[int] = mapped_column(Integer, nullable=False)
    actif: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    rendez_vous: Mapped[list["RendezVous"]] = relationship(back_populates="medecin")


class Patient(Base):
    """Fiche patient (aucune donnée médicale n'est stockée)."""

    __tablename__ = "patients"

    id: Mapped[str] = mapped_column(String(12), primary_key=True)
    nom: Mapped[str] = mapped_column(String(80), nullable=False)
    prenom: Mapped[str] = mapped_column(String(80), nullable=False)
    sexe: Mapped[Sexe] = mapped_column(_type_enum(Sexe, "sexe_patient"), nullable=False)
    # Facultatifs en base : l'historique importé peut être incomplet. La création par l'API
    # (schémas Pydantic) les exige.
    date_naissance: Mapped[date | None] = mapped_column(Date, nullable=True)
    telephone: Mapped[str | None] = mapped_column(String(9), nullable=True)
    quartier: Mapped[str | None] = mapped_column(String(60), nullable=True)
    cree_le: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=maintenant)

    rendez_vous: Mapped[list["RendezVous"]] = relationship(back_populates="patient")


_CLAUSE_ACTIF = "statut IN (" + ", ".join(f"'{s.value}'" for s in STATUTS_ACTIFS) + ")"


class RendezVous(Base):
    """Rendez-vous entre un patient et un médecin, saisi par un agent."""

    __tablename__ = "rendez_vous"
    __table_args__ = (
        CheckConstraint("fin > debut", name="ck_rdv_fin_apres_debut"),
        # RG-05 en base : un motif existe si et seulement si le rendez-vous est annulé.
        CheckConstraint(
            "(statut = 'Annulé' AND motif_annulation IS NOT NULL) "
            "OR (statut <> 'Annulé' AND motif_annulation IS NULL)",
            name="ck_rdv_motif_annulation",
        ),
        # RG-01 / RG-02 en base : filet de sécurité contre deux écritures simultanées
        # sur un même créneau (la vérification de chevauchement se fait avant l'insertion).
        Index(
            "uq_rdv_medecin_debut_actif",
            "medecin_id",
            "debut",
            unique=True,
            sqlite_where=text(_CLAUSE_ACTIF),
            postgresql_where=text(_CLAUSE_ACTIF),
        ),
        Index(
            "uq_rdv_patient_debut_actif",
            "patient_id",
            "debut",
            unique=True,
            sqlite_where=text(_CLAUSE_ACTIF),
            postgresql_where=text(_CLAUSE_ACTIF),
        ),
        Index("ix_rdv_debut_statut", "debut", "statut"),
    )

    id: Mapped[str] = mapped_column(String(12), primary_key=True)
    patient_id: Mapped[str] = mapped_column(
        ForeignKey("patients.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    medecin_id: Mapped[str] = mapped_column(
        ForeignKey("medecins.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    agent_id: Mapped[str] = mapped_column(
        ForeignKey("agents.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    date_prise: Mapped[date] = mapped_column(Date, nullable=False)
    debut: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    fin: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    statut: Mapped[StatutRdv] = mapped_column(
        _type_enum(StatutRdv, "statut_rdv"), nullable=False, default=StatutRdv.PLANIFIE
    )
    confirme: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    canal: Mapped[Canal | None] = mapped_column(_type_enum(Canal, "canal_rdv"), nullable=True)
    motif_annulation: Mapped[MotifAnnulation | None] = mapped_column(
        _type_enum(MotifAnnulation, "motif_annulation"), nullable=True
    )
    cree_le: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=maintenant)
    modifie_le: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=maintenant, onupdate=maintenant
    )

    patient: Mapped[Patient] = relationship(back_populates="rendez_vous", lazy="joined", innerjoin=True)
    medecin: Mapped[Medecin] = relationship(back_populates="rendez_vous", lazy="joined", innerjoin=True)
    agent: Mapped[Agent] = relationship(back_populates="rendez_vous")

    # --- Propriétés calculées, utilisées pour la sérialisation de l'API ---------------

    @property
    def date_rdv(self) -> date:
        """Date du rendez-vous."""
        return self.debut.date()

    @property
    def heure_rdv(self) -> time:
        """Heure de début du rendez-vous."""
        return self.debut.time()

    @property
    def duree_min(self) -> int:
        """Durée du rendez-vous en minutes."""
        return int((self.fin - self.debut).total_seconds() // 60)

    @property
    def specialite(self) -> str:
        """Spécialité du médecin."""
        return self.medecin.specialite

    @property
    def medecin_nom(self) -> str:
        """Nom du médecin."""
        return self.medecin.nom

    @property
    def patient_nom(self) -> str:
        """Nom complet du patient (nom puis prénom)."""
        return f"{self.patient.nom} {self.patient.prenom}"
